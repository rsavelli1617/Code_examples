clear all
close all

load ElwhaGF20132014.mat
SPM_sea = double(aqd.obs.*1000);
time_sea = aqd.td;
time_sea = datetime(datestr(time_sea));
SPM_sea_tt = timetable(time_sea,SPM_sea);
SPM_sea_tt_day = retime(SPM_sea_tt,'daily','mean');

% Htide = (aqd.pres-nanmean(aqd.pres))>0;
% Ltide = (aqd.pres-nanmean(aqd.pres))<0;
% SPM_sea_ttHT = timetable(time_sea(Htide),SPM_sea(Htide));
% SPM_sea_tt_dayHT = retime(SPM_sea_ttHT,'daily','mean');
% 
% SPM_sea_ttLT = timetable(time_sea(Ltide),SPM_sea(Ltide));
% SPM_sea_tt_dayLT = retime(SPM_sea_ttLT,'daily','mean');

river = readtable('Elwha_DailySedimentLoads_2011to2016.csv');
time_river = river.Day;
DailySSC_river = river.DailySSC_mg_L_;
Dailydischarge = river.DailyDischarge_m3_s_;
TotalSDischarge = river.TotalSedimentDischarge_tonnes_;
%% PLOT
close all

plot(SPM_sea_tt_day.time_sea,SPM_sea_tt_day.SPM_sea); hold on
plot(time_river,DailySSC_river);

%% Scatter
close all
[logical_Index,index] = ismember(SPM_sea_tt_day.time_sea,time_river);
scatter(log(DailySSC_river(index)),log(SPM_sea_tt_day.SPM_sea))

% [logical_Index,indexHT] = ismember(SPM_sea_tt_dayHT.Time,time_river);
% scatter(TotalSDischarge(indexHT),SPM_sea_tt_dayHT.Var1)
% 
% [logical_Index,indexLT] = ismember(SPM_sea_tt_dayLT.Time,time_river);
% scatter(TotalSDischarge(indexLT),SPM_sea_tt_dayLT.Var1)

X = [log(DailySSC_river(index))];
mdl = fitlm(X,log(SPM_sea_tt_day.SPM_sea))

[curve, gof] = fit(log(Dailydischarge(index)),log(SPM_sea_tt_day.SPM_sea),'exp1')
plot(curve,Dailydischarge(index),SPM_sea_tt_day.SPM_sea)